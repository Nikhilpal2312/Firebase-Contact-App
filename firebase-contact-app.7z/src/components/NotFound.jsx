import React from 'react'

const NotFound = () => {
  return (
    <div className='flex h-[80vh] justify-center items-center h-screen gap-4'>
      <img src='./images/Hands Contact.png' alt='' />
      <h3 className='text-white text-2xl font-semi-bold '>Contact Not Found</h3>
    </div>
  )
}

export default NotFound
