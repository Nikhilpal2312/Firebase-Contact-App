import React from 'react';

const Navbar = () => {
  return (
    <div className='flex justify-center items-center my-4 h-[60px] rounded-lg bg-white text-center gap-3 text-xl font-medium'>
    <img src="/images/logos_firebase.png" alt="logo"/>
    <h1>Firebase Contact App</h1>
    </div>
  )
}

export default Navbar;
