import React from 'react';
import {BiUserCircle} from 'react-icons/bi';
import {RiEditCircleFill} from 'react-icons/ri';
import {MdDelete} from 'react-icons/md';
import { deleteDoc, doc } from 'firebase/firestore';
import { db } from '../config/firebase';
import AddUpdateContact from './AddUpdateContact';
import useDisclouse from '../hooks/useDisclouse';
import { ToastContainer, toast } from 'react-toastify';

const ContactCard = ({contact}) => {

    const {isOpen, onOpen, onClose} =useDisclouse();

    const deleteContact = async (id) => {
        try {
            
            await deleteDoc (doc(db, "contacts", id));
            toast.success("Contact deleted successfully")


        } catch (error) {
            console.log(error)
        }
    }



  return (
    <>
       <div key={contact.id} className='mt-4 bg-yellow flex items-center justify-between p-2 rounded-lg'>
           <div className='flex gap-1'>
           <BiUserCircle className='text-4xl rounded-md'/>
            <div className=''>
              <h2 className="font-medium">{contact.name}</h2>
              <p className='text-sm'>{contact.email}</p>
            </div>
           </div>
            <div className='flex text-3xl'>
              <RiEditCircleFill onClick={onOpen} className='cursor-pointer'/>
            <MdDelete onClick={()=> deleteContact(contact.id)} className='text-orange cursor-pointer'/>
            </div>
          </div>
          <AddUpdateContact isUpdate isOpen={isOpen} onClose={onClose}  contact={contact}/>
          <ToastContainer position='bottom-center'/>
    </>
    
  )
}

export default ContactCard
