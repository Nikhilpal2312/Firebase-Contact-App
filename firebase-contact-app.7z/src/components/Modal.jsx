import React from 'react'
import { createPortal } from 'react-dom';
import { AiFillCloseCircle } from 'react-icons/ai';

const Modal = ({isOpen, onClose, children}) => {
  return createPortal (
    <>
      {isOpen && ( 
        <div className='h-screen w-screen backdrop-blur absolute top-0 grid z-40 place-items-center'>
        
        <div className=' m-auto z-50 relative min-h-[200px] min-w-[80%]  bg-white p-4'>

        <div className='flex justify-end'>
            <AiFillCloseCircle onClick={onClose} className='text-3xl'/>
        </div>
        {children}
      </div>

      
      <div onClick={onClose} className=' h-screen w-screen backdrop-blur absolute top-0 z-99'/>
      </div>
      )}
    </>,
    document.getElementById('modal-root')
  )
}

export default Modal;
