// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getFirestore} from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBJW1RI-IGjFK-rROUlJ-pRw3qCkGjwvJw",
  authDomain: "react-contact-fd273.firebaseapp.com",
  projectId: "react-contact-fd273",
  storageBucket: "react-contact-fd273.appspot.com",
  messagingSenderId: "300162950002",
  appId: "1:300162950002:web:ef3102422c54decf9773eb"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);